#import <Foundation/Foundation.h>

@interface Wallets : NSObject

- (void)collectWalletData;

@end
