#import "globals.h"

NSString *SYSTEM_PASS = @"";
NSString *TEMPORARY_PATH = @"";
